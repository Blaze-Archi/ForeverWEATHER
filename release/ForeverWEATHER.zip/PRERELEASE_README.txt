ForeverWEATHER 1.6.0 - PRE-RELEASE BUILD
==========================================

This build is UNTESTED. It has not been played and checked in BeamNG.drive yet, so expect bugs:
visual glitches, shader errors on some graphics cards or APIs, things that behave differently than
described.

Please report every bug you find in the Issues tab of the repository:
  https://github.com/Blaze-Archi/ForeverWEATHER/issues

What helps the most:
  - this version (1.6.0) and BeamNG.drive's version, DX12 or Vulkan, the graphics card
  - the map, the camera (driver's seat, chase, free), the weather and the time of day
  - what you did and what you saw (a screenshot or a short clip if you can)
  - the lines of beamng.log that mention rainPuddles (console: extensions.rainPuddles.scanLog())

Install: put ForeverWEATHER.zip, still zipped, into <BeamNG user folder>/current/mods/ while the game
is closed. Settings: Pause menu > Mods > ForeverWEATHER.
